
public class Datum {
	public Word word;
	public Integer frequency;
	
	public Datum(Word word, Integer frequency){
		this.word = word;
		this.frequency = frequency;
	}
}

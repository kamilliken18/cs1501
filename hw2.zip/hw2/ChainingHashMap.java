
public class ChainingHashMap{
	Node[] array;
	int size;
	
	public ChainingHashMap(int size){
		this.size = size;
		array = new Node[size];
	}

	public Integer get(Word key) {
	// Problem #1A
	// Fill in this method to get the value corresponding
	// with the key. Note: if the key is not found, then
	// return null.

		if (key == null) {
		//there is no key to search with!
			return null;
		}
	 
		int hashIndex = key.hashCode()%array.length;
		Node value = array[hashIndex];

		if(value == null) {
		//there isn't an element to search
			return null;
		}
		while(value.word != key && value != null){
			value = value.next;
		}
		if(value.equals(key)) {
		//found it!
			return value.frequency;
		}
		else {
		//didn't find it
			return null;
		}
	 
	}

	public void put(Word key, Integer value) {
	// Problem #1B
	// Fill in this method to insert a new key-value pair into
	// the map or update the existing key-value pair if the
	// key is already in the map.
		int hashIndex = key.hashCode()%array.length;
		Node valerie = array[hashIndex];
		if(key == null){
			// exit the method; there's nothing to put in!
			return;
		}
		if(valerie == null){ 
			// node doesn't exist, make new node
			array[hashIndex] = new Node(key,value,null);
		}
		else{
		// node does exist
			while(valerie.next != null && valerie.word != key){
				valerie = valerie.next;
			}
			if(valerie.word == key) {
			//found it; update it
				valerie.frequency = value;
			}
			else {
			//didn't find it, make new node
				valerie.next = new Node(key,value,null);
			}
		}

	}

	public Integer remove(Word key) {
	// Problem #1C
	// Fill in this method to remove a key-value pair from the
	// map and return the corresponding value. If the key is not
	// found, then return null.

	int hashIndex = key.hashCode()%array.length;
	Node oldNode = null;
	Node val = array[hashIndex];
		if( val == null){
			//if there is no element, can't remove it
			return null;
		}
		else{
			while(val.word!= key && val.next!= null){
				// searching for node
				oldNode = val;
				val = val.next;
			}
			if(val.word == key){
				//found it, remove node
				if(oldNode == null){
					
					array[hashIndex] = val.next;
					return val.frequency;
				}
				else{
					oldNode.next = val.next;
					return val.frequency;
				}
			}
		}
		return null;
	}
	
	// This method returns the total size of the underlying array.
	// In other words, it returns the total number of linkedlists.
	public int getSize(){
		return size;
	}
	
	// This method counts how many keys are stored at the given array index.
	// In other words, it computes the size of the linkedlist at the given index.
	public int countCollisions(int index){
		if(index < 0 || index >= size) return -1;
		
		int count = 0;
		Node temp = array[index];
		while(temp != null){
			temp = temp.next;
			count++;
		}
		
		return count;
	}
	
}

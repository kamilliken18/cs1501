import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class BFS {

	// Returns the set of reachable locations using breadth first Search
	
	public static Set<Location> getReachableSet(WeightedGraph graph, Location start){
	// Problem #1
	// Fill in this method to compute the set of all possible reachable 
	// locations (ignoring costs and budget).  You must use Breadth
	// First Search to get full credit.
		Queue queue = new LinkedList<Location>();
		Set visitSet = new HashSet<Location>();
		final int INFINITY = Integer.MAX_VALUE;
		HashMap<Location,Boolean> added = new HashMap<Location,Boolean>();
        HashMap<Location,Integer> vLevel = new HashMap<Location,Integer>();
        HashMap<Location,Location> lastEdge = new HashMap<Location,Location>();

		for( Location loc : graph.getNeighbors(start)) {
			vLevel.put(loc, INFINITY);
			added.put(loc,false);
			lastEdge.put(loc,null);
		}
		vLevel.put(start, 0); 
		queue.add(start);

 		while (!queue.isEmpty()) { // while the queue still has locations
            Location vert = (Location)queue.poll();
			visitSet.add(vert);
			added.put(vert,true);
			Iterator<Location> neighbors = graph.getNeighbors(vert).iterator(); //gets all the neighbors of the vertex
            while (neighbors.hasNext()) { // while the node in qustion still has neighbors 
				Location newVert = neighbors.next(); //get the neighbor
				//System.out.println(newVert.name);
                if (!visitSet.contains(newVert)) { //if this neighbor is not already in the spanning tree then add it 
					queue.add(newVert); //to the queue
                    lastEdge.put(newVert, vert); //to the map of neighbors
                    vLevel.put(newVert, vLevel.get(vert) + 1); //to the level
                    added.put(newVert, true); //to the hashmap confirming whether in the spanning tree
                }
            }
		 }
		return visitSet;

	}
}

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.LinkedList;
import java.util.Queue;


public class Dijkstra {

	// Returns the set of destinations that can be reached without going over budget
	public static Set<Location> getDestinationSet(WeightedGraph graph, Location start, Integer budget){
	// Problem #2
	// Fill in this method to compute the set of all possible destinations 
	// that can be reached while staying within the travel budget. You must
	// use Dijkstra's algorithm to get full credit.  We encourage you to
	// implement the |V|^2 time version of Dijkstra's algorithm.  You are
	// free to add helper methods. 
		Queue queue = new LinkedList<Location>();
		Set visitSet = new HashSet<Location>();
		final int INFINITY = Integer.MAX_VALUE;
        HashMap<Location,Integer> vLevel = new HashMap<Location,Integer>();
		HashMap<Location,Boolean> added = new HashMap<Location,Boolean>();

		vLevel.put(start, 0); 
		queue.add(start);
		visitSet.add(start);
		added.put(start,true);


		for( Location loc : graph.getNeighbors(start)) {
			vLevel.put(loc, INFINITY);
			added.put(loc,false);
		}

 		while (!queue.isEmpty()) { // while the queue still has locations
            Location vert = (Location)queue.poll();
			if (!visitSet.contains(vert)) {
				visitSet.add(vert);
				added.put(vert,true);
			}
			Iterator<Location> neighbors = graph.getNeighbors(vert).iterator(); //gets all the neighbors of the vertex
            while (neighbors.hasNext()) { // while the node in qustion still has neighbors 
				Location newVert = neighbors.next(); //get the neighbor
				int newSize = vLevel.get(vert)+graph.getWeight(vert, newVert);
				if (newSize > budget) { //gotta check with the budget first
					continue;
				}
                if (!vLevel.containsKey(newVert)) { //if we haven't visited this node before and its within budget
                    vLevel.put(newVert, newSize); 
					added.put(newVert,true);
                }
				else{
					if(newSize > vLevel.get(newVert)) { 
						continue;
					}
					vLevel.put(newVert, newSize); 
					added.put(vert,true);
				}
				queue.add(newVert);
            }
		 }
		return visitSet;
	}
	
}
